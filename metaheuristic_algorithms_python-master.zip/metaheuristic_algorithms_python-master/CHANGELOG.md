## metaheuristic_algorithms_python 0.1.5 (November 22, 2015) ##

* Added command line script. 

## metaheuristic_algorithms_python 0.1.4 (November 21, 2015) ##

* Fixed packages in setup.py so that metaheuristic_algorithms_python.function_wrappers subpackage is included. 

## metaheuristic_algorithms_python 0.1.3 (November 12, 2015) ##

* Added Firefly Algorithm

## metaheuristic_algorithms_python 0.1.2 (November 9, 2015) ##

* Fixed a typo in method name minimum_decision_variable_values in FunctionWrapper's.

* Added Simulated Annealing

## metaheuristic_algorithms_python 0.1.1 (November 3, 2015) ##

* Added Simplified Particle Swarm Optimization

## metaheuristic_algorithms_python 0.1.0 (October 26, 2015) ##

* Added Harmony Search
