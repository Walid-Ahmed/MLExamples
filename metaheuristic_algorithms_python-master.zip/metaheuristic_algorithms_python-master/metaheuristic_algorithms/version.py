# Based on Semantic Versioning (http://semver.org/)
__version__ = "0.1.6"